# Ellie's Dig Spot

This mod replaces the dig spot with an "X" marks the spot.

There are three animation options: false, pulse, and bounce. All options have the default shake animation from the game.